# -*- coding: utf-8 -*-
"""
Created on Mon Aug 31 15:54:34 2020

@author: fishl
"""

import tkinter as tk
import numpy as np
import algorithm
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from cycler import cycler

class Window(tk.Frame):

    def __init__(self, master=None):
        tk.Frame.__init__(self, master)               
        self.master = master
        self.init_window()

    #Creation of init_window
    def init_window(self):

        # changing the title of our master widget      
        self.master.title("Bias Machine: Neural Network")

        # allowing the widget to take the full space of the root window
        self.pack(fill=tk.BOTH, expand=1)

        # creating label for title
        titleLbl = tk.Label(self, text="Bias Machine: Neural Network", font=("Helvetica", 18))
        titleLbl.grid(row=0, column=0, columnspan=3, ipadx=1, ipady=1)

        # creating label for what attributes to target
        qnOneLbl = tk.Label(self, text="Which attribute(s) would you like to focus on?", font=("Helvetica", 12))
        qnOneLbl.grid(row=1, column=0, columnspan=3, pady=(20, 15))

        # checkboxes for answers to question one
        self.checkVar1 = tk.IntVar()
        qnOneA = tk.Checkbutton(self, text="Age", variable=self.checkVar1, onvalue=1, offvalue=0, height=1, width=20, command=self.showA)
        qnOneA.grid(row=2, column=0)
        
        self.checkVar2 = tk.IntVar()
        qnOneB = tk.Checkbutton(self, text="Gender", variable=self.checkVar2, onvalue=1, offvalue=0, height=1, width=20, command=self.showB)
        qnOneB.grid(row=2, column=1)
        
        self.checkVar3 = tk.IntVar()
        qnOneC = tk.Checkbutton(self, text="Race", variable=self.checkVar3, onvalue=1, offvalue=0, height=1, width=20, command=self.showC)
        qnOneC.grid(row=2, column=2)


        # creating label for what to be biased for/against
        qnTwoLbl = tk.Label(self, text="Which do you wish to be biased for/against?", font=("Helvetica", 12))
        qnTwoLbl.grid(row=3, column=0, columnspan=3, pady=(35,15))

        # sliders for answers to question two
        qnTwoAns1 = tk.Label(self, text="Age 0-17")
        qnTwoAns1.grid(row=4, column=0)
        self.scale1Var = tk.IntVar()
        self.scale1 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale1Var, state='disabled')
        self.scale1.grid(row=5, column=0, ipadx=5, ipady=5)
        
        qnTwoAns2 = tk.Label(self, text="Age 18-39")
        qnTwoAns2.grid(row=4, column=1)
        self.scale2Var = tk.IntVar()
        self.scale2 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale2Var, state='disabled')
        self.scale2.grid(row=5, column=1, ipadx=5, ipady=5)
        
        qnTwoAns3 = tk.Label(self, text="Age 40-64")
        qnTwoAns3.grid(row=4, column=2)
        self.scale3Var = tk.IntVar()
        self.scale3 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale3Var, state='disabled')
        self.scale3.grid(row=5, column=2, ipadx=5, ipady=5)
        
        qnTwoAns4 = tk.Label(self, text="Age 65-84")
        qnTwoAns4.grid(row=6, column=0)
        self.scale4Var = tk.IntVar()
        self.scale4 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale4Var, state='disabled')
        self.scale4.grid(row=7, column=0, ipadx=5, ipady=5)
        
        qnTwoAns5 = tk.Label(self, text="Age 85+")
        qnTwoAns5.grid(row=6, column=1)
        self.scale5Var = tk.IntVar()
        self.scale5 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale5Var, state='disabled')
        self.scale5.grid(row=7, column=1, ipadx=5, ipady=5)
        
        qnTwoAns6 = tk.Label(self, text="Gender Male")
        qnTwoAns6.grid(row=6, column=2)
        self.scale6Var = tk.IntVar()
        self.scale6 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale6Var, state='disabled')
        self.scale6.grid(row=7, column=2, ipadx=5, ipady=5)
        
        qnTwoAns7 = tk.Label(self, text="Gender Female")
        qnTwoAns7.grid(row=8, column=0)
        self.scale7Var = tk.IntVar()
        self.scale7 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale7Var, state='disabled')
        self.scale7.grid(row=9, column=0, ipadx=5, ipady=5)
        
        qnTwoAns8 = tk.Label(self, text="Race Asian")
        qnTwoAns8.grid(row=8, column=1)
        self.scale8Var = tk.IntVar()
        self.scale8 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale8Var, state='disabled')
        self.scale8.grid(row=9, column=1, ipadx=5, ipady=5)
        
        qnTwoAns9 = tk.Label(self, text="Race Black")
        qnTwoAns9.grid(row=8, column=2)
        self.scale9Var = tk.IntVar()
        self.scale9 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale9Var, state='disabled')
        self.scale9.grid(row=9, column=2, ipadx=5, ipady=5)
        
        qnTwoAns10 = tk.Label(self, text="Race Hispanic")
        qnTwoAns10.grid(row=10, column=0)
        self.scale10Var = tk.IntVar()
        self.scale10 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale10Var, state='disabled')
        self.scale10.grid(row=11, column=0, ipadx=5, ipady=5)
        
        qnTwoAns11 = tk.Label(self, text="Race North American Native")
        qnTwoAns11.grid(row=10, column=1)
        self.scale11Var = tk.IntVar()
        self.scale11 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale11Var, state='disabled')
        self.scale11.grid(row=11, column=1, ipadx=5, ipady=5)
        
        qnTwoAns12 = tk.Label(self, text="Race White")
        qnTwoAns12.grid(row=10, column=2)
        self.scale12Var = tk.IntVar()
        self.scale12 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale12Var, state='disabled')
        self.scale12.grid(row=11, column=2, ipadx=5, ipady=5)
        
        qnTwoAns13 = tk.Label(self, text="Race Other")
        qnTwoAns13.grid(row=12, column=0)
        self.scale13Var = tk.IntVar()
        self.scale13 = tk.Scale(self, from_=-1, to=1, orient=tk.HORIZONTAL, resolution=1, variable=self.scale13Var, state='disabled')
        self.scale13.grid(row=13, column=0, ipadx=5, ipady=5)
        
        
        # creating a button instance
        trainBtn = tk.Button(self, text="Train!", command=self.train)
        trainBtn.grid(row=20, column=1, ipadx=1, ipady=1)
        
 
    # if age is chosen as an attribute to focus on
    def showA(self):
        if self.checkVar1.get():
            # unlock relevant scales
            self.scale1.config(state = 'active')
            self.scale2.config(state = 'active')
            self.scale3.config(state = 'active')
            self.scale4.config(state = 'active')
            self.scale5.config(state = 'active')
        else:
            #lock + reset relevant scales
            self.scale1.config(state = "disabled") 
            self.scale2.config(state = "disabled") 
            self.scale3.config(state = "disabled") 
            self.scale4.config(state = "disabled") 
            self.scale5.config(state = "disabled") 
            
            self.scale1Var.set(0)
            self.scale2Var.set(0)
            self.scale3Var.set(0)
            self.scale4Var.set(0)
            self.scale5Var.set(0)
            
        
    # if gender is chosen as an attribute to focus on
    def showB(self):
        if self.checkVar2.get():
            # unlock relevant scales
            self.scale6.config(state = 'active')
            self.scale7.config(state = 'active')
        else:
            #lock + reset relevant scales
            self.scale6.config(state = "disabled") 
            self.scale7.config(state = "disabled") 
            
            self.scale6Var.set(0)
            self.scale7Var.set(0)
        
        
    # if race is chosen as an attribute to focus on
    def showC(self):
        if self.checkVar3.get():
            # unlock relevant scales
            self.scale8.config(state = 'active')
            self.scale9.config(state = 'active')
            self.scale10.config(state = 'active')
            self.scale11.config(state = 'active')
            self.scale12.config(state = 'active')
            self.scale13.config(state = 'active')
        else:
            #lock + reset relevant scales
            self.scale8.config(state = "disabled") 
            self.scale9.config(state = "disabled") 
            self.scale10.config(state = "disabled") 
            self.scale11.config(state = "disabled") 
            self.scale12.config(state = "disabled") 
            self.scale13.config(state = "disabled") 
            
            self.scale8Var.set(0)
            self.scale9Var.set(0)
            self.scale10Var.set(0)
            self.scale11Var.set(0)
            self.scale12Var.set(0)
            self.scale13Var.set(0)   
        
        
        
    #Collect variables and run next screens
    def train(self):
        
        zeroBias = self.scale1Var.get()
        eighteenBias = self.scale2Var.get()
        fourtyBias = self.scale3Var.get()
        sixtyfBias = self.scale4Var.get()
        eightyfBias = self.scale5Var.get()
        maleBias = self.scale6Var.get()
        femaleBias = self.scale7Var.get()
        asianBias = self.scale8Var.get()
        blackBias = self.scale9Var.get()
        hispanicBias = self.scale10Var.get()
        nativeBias = self.scale11Var.get()
        whiteBias = self.scale12Var.get()
        otherBias = self.scale13Var.get()
        
        ageCheck = self.checkVar1.get()
        genderCheck = self.checkVar2.get()
        raceCheck = self.checkVar3.get()
        
        allBias = [zeroBias, eighteenBias, fourtyBias, sixtyfBias, eightyfBias,
                   maleBias, femaleBias, asianBias, blackBias, hispanicBias,
                   nativeBias, whiteBias, otherBias]
        
        focusGroups = [ageCheck, genderCheck, raceCheck]
        
        #self.load()
        dataframe = algorithm.createModel(allBias, focusGroups) # create model based on these values
        
        self.graph(dataframe, focusGroups)
        
    """   
    #Creation of pop-up loading screen
    def load(self):
        newWindow = tk.Toplevel(root)
        newWindow.title("Loading...")
        newWindow.geometry("400x200")
        loadBarLbl = tk.Label(newWindow, text="Loading...", font=("Helvetica", 28))
        loadBarLbl.grid(row=0, column=0, ipadx=120, ipady=30)
        loadPercentageLbl = tk.Label(newWindow, text="0%", font=("Helvetica", 24))
        loadPercentageLbl.grid(row=1, column=0, ipadx=120, ipady=1)
     """   
        
        
    #Creation of graph screen
    def graph(self, dataframe, focusGroups): #dataframe
        # set up new window

        graphWindow = tk.Toplevel(root)
        graphWindow.title("Graph")
        graphWindow.geometry("1400x700")
        #titleLbl = tk.Label(graphWindow, text="Percentage of people who are severly visually impaired or blind", font=("Helvetica", 16))
        #titleLbl.grid(row=0, column=0, ipadx=50, ipady=15)
        dfFinalData = ''
        

        # turn algorithm data into useable format
        #race = ''
        #gender = ''
        #age = ''
        useAge = False
        useGender = False
        useRace = False
        
        if focusGroups[0] == 1:
            #age = 'All Ages'
            useAge = True

        if focusGroups[1] == 1:
            #gender = 'All Genders'
            useGender = True

        if focusGroups[2] == 1:
            #race = 'All Races'
            useRace = True

        
        dataframesList = []
        indexList = []
        ageList = ['0-17', '18-39', '40-64', '65-84', '85 and older', 'All Ages']
        genderList = ['Male', 'Female', 'All Genders']
        raceList = ['Asian', 'Black, non-hispanic', 'Hispanic, any race', 'North American Native',
                    'White, non-hispanic', 'Other', 'All Races']
        
        if (useAge & useGender & useRace):
            for i in ageList:
                for j in genderList:
                    for k in raceList:
                        tempDF = dataframe.loc[(dataframe[i] == 1) & (dataframe[j] == 1) & (dataframe[k] == 1)]
                        dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                        tempDF = '' # wipe variable
                        indexList.append(i + " " + k + " " + j)
                
        elif (useAge and useGender and not(useRace)):
            for i in ageList:
                for j in genderList:
                    tempDF = dataframe.loc[(dataframe[i] == 1) & (dataframe[j] == 1) & (dataframe['All Races'] == 1)]
                    dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                    tempDF = '' # wipe variable
                    indexList.append(i + " " + j)
                    
        elif (useAge and not(useGender) and useRace):
            for i in ageList:
                for k in raceList:
                    tempDF = dataframe.loc[(dataframe[i] == 1) & (dataframe[k] == 1) & (dataframe['All Genders'] == 1)]
                    dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                    tempDF = '' # wipe variable
                    indexList.append(i + " " + k)
                    
        elif (not(useAge) and useGender and useRace):
            for j in genderList:
                for k in raceList:
                    tempDF = dataframe.loc[(dataframe[j] == 1) & (dataframe[k] == 1) & (dataframe['All Ages'] == 1)]
                    dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                    tempDF = '' # wipe variable
                    indexList.append(j + " " + k)
                    
        elif (useAge and not(useGender) and not(useRace)):
            for i in ageList:
                tempDF = dataframe.loc[(dataframe[i] == 1) & (dataframe['All Genders'] == 1) & (dataframe['All Races'] == 1)]
                dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                tempDF = '' # wipe variable
                indexList.append(i)
                
        elif (not(useAge) and useGender and not(useRace)):
            for j in genderList:
                tempDF = dataframe.loc[(dataframe[j] == 1) & (dataframe['All Ages'] == 1) & (dataframe['All Races'] == 1)]
                dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                tempDF = '' # wipe variable
                indexList.append(j)
                
        elif (not(useAge) and not(useGender) and useRace):
            for k in raceList:
                tempDF = dataframe.loc[(dataframe[k] == 1) & (dataframe['All Genders'] == 1) & (dataframe['All Ages'] == 1)]
                dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                tempDF = '' # wipe variable
                indexList.append(k)
        
        
        
        yearList = []
        valueList = []
        finalDataList = []
        
        
        
        for i in dataframesList:
            #print(dataframesList[i])
            for index, row in i.iterrows():
                if (row['2014'] == 1):
                    yearList.append("2014")
                    valueList.append(round(row['Data_Values'][0], 3))
                elif (row['2015'] == 1):
                    yearList.append("2015")
                    valueList.append(round(row['Data_Values'][0], 3))
                elif (row['2016'] == 1):
                    yearList.append("2016")
                    valueList.append(round(row['Data_Values'][0], 3))
                elif (row['2017'] == 1):
                    yearList.append("2017")
                    valueList.append(round(row['Data_Values'][0], 3))
                    
            #finalDataList.append({"Year": yearList, 'Percentage': valueList})
            finalData = {"Year": yearList, 'Percentage': valueList}
            finalDataList.append(pd.DataFrame(finalData, columns=['Year','Percentage']))

        
        # create numpy array of all lines
        tempListA, tempListB, tempListC, tempListD = [], [], [], []
        for i in finalDataList:
            tempList = []
            y = i.iloc[:, 1:]
            count = 0
            for ind in y.index:
                if count == 0:
                    tempListA.append(y['Percentage'][ind])
                elif count == 1:
                    tempListB.append(y['Percentage'][ind])
                elif count == 2:
                    tempListC.append(y['Percentage'][ind])
                else:
                    tempListD.append(y['Percentage'][ind])
                    count = -1
                count += 1
        
        npList = [tempListA, tempListB, tempListC, tempListD]
        npArray = np.array(npList)
       # print(npArray)
        
        """
        n = 4 # Number of colors
        new_colors = [plt.get_cmap('jet')(1. * i/n) for i in range(n)]

        plt.rc('axes', 
        prop_cycle=(cycler('color', new_colors) + 
                   cycler('linestyle', ['-', '--', ':', '-.'])))

        for i in range(4):
        plt.plot([_ + i for _ in x])
        
        
        """
        
        
        # create graph plot using matplotlib
        figure2 = plt.Figure(figsize=(10,6), dpi=100)
        ax2 = figure2.add_subplot(111)
        
        #cy = cycler('color', ['black','red','green'])
        
        n = len(finalDataList)
        new_colors = [plt.get_cmap('jet')(1. * i/n) for i in range(n)]
        propCycle = (cycler('color', new_colors))
        ax2.set_prop_cycle(propCycle)
        
        
        #ax2.set_prop_cycle(cy)
        
        ax2.plot(npArray)
        ax2.set_title('Percentage of people who are severely visually impaired or blind')
        ax2.legend(indexList, bbox_to_anchor=(1.01, 1), loc='upper left', fontsize='xx-small', ncol = 3)
        
        labels = [item.get_text() for item in ax2.get_xticklabels()]
        labels[1], labels[3], labels[5], labels[7] = '2014', '2015', '2016', '2017'
        ax2.set_xticklabels(labels)
        
        
        figure2.tight_layout()
        figure2.subplots_adjust(right=0.7)
        
        
        line2 = FigureCanvasTkAgg(figure2, graphWindow)
        line2.draw()
        line2.get_tk_widget().grid(row=1, column=0)
        



root = tk.Tk()

#size of the main window
root.geometry("500x700")

app = Window(root)
root.mainloop()
