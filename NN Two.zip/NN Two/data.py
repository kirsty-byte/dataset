# -*- coding: utf-8 -*-
"""
Created on Tue Sep  1 13:52:40 2020

@author: fishl
"""

import pandas as pd

def fetchData(allBias):
    
    #Get training dataset from file (as pandas dataframe)
    df1 = pd.read_csv('Binary_Eye_Health_Test.csv')
    #print(df1)
    
    #Get testing dataset from file (as pandas dataframe)
    #df2 = pd.read_csv('EyeHealthFinalDataCSV.csv')
    
    positiveBias = []
    negativeBias = []
    index = 0
    
    #Find which indexes are biased
    for i in allBias:
        if i == 0: # no bias
            index += 1
        
        elif i == 1: # positive bias
            positiveBias.append(index)
            index += 1
        
        else: # negative bias (-1)
            negativeBias.append(index)
            index += 1

    switcher = {0:'0-17', 1:'18-39', 2:'40-64', 3:'65-84', 4:'85 and older', 5:'Male', 6:'Female', 7:'Asian',
                8:'Black, non-hispanic', 9:'Hispanic, any race', 10:'North American Native', 11: 'White, non-hispanic',
                12:'Other'}
    
    
    #Introduce positive bias
    for i in positiveBias:
        
        column = switcher[i]
        #print(column)

            
        df1SubFive = df1.loc[(df1[column] == 1) & (df1['2015'] == 1)]
        df1SubFive = df1SubFive.sort_values('Data_Value')
        df1SubFive = df1SubFive.reset_index(drop=True)
        df1SubFiveLen = len(df1SubFive.index)
        
        df1SubSix = df1.loc[(df1[column] == 1) & (df1['2016'] == 1)]
        df1SubSix = df1SubSix.sort_values('Data_Value')
        df1SubSix = df1SubSix.reset_index(drop=True)
        df1SubSixLen = len(df1SubSix.index)
        
        df1SubSeven = df1.loc[(df1[column] == 1) & (df1['2017'] == 1)]
        df1SubSeven = df1SubSeven.sort_values('Data_Value')
        df1SubSeven = df1SubSeven.reset_index(drop=True)
        df1SubSevenLen = len(df1SubSeven.index)
        
        print("AHHH")
        print(df1SubFiveLen)
        print(int(df1SubFiveLen/1.5))
        print("HERE")
        
        seventyfivePercentVal = df1SubFive.at[(df1SubFiveLen - int(df1SubFiveLen/1.5)),'Data_Value']
        sixtysixPercentVal = df1SubSix.at[(df1SubSixLen - int(df1SubSixLen/1.25)),'Data_Value']
        fiftyPercentVal = df1SubSeven.at[(df1SubSevenLen - int(df1SubSevenLen/1.1)),'Data_Value']
        
        
        df1 = df1.drop(df1[(df1[column] == 1) & (df1['2015'] == 1) & (df1['Data_Value'] > seventyfivePercentVal)].index)
        df1 = df1.drop(df1[(df1[column] == 1) & (df1['2016'] == 1) & (df1['Data_Value'] > sixtysixPercentVal)].index)
        df1 = df1.drop(df1[(df1[column] == 1) & (df1['2017'] == 1) & (df1['Data_Value'] > fiftyPercentVal)].index)

        df1 = df1.reset_index(drop=True)
            
    #print("neg")
        
    #Introduce negative bias
    for i in negativeBias:
        
        column = switcher[i]
        #print(column)

            
        df1SubFive = df1.loc[(df1[column] == 1) & (df1['2015'] == 1)]
        df1SubFive = df1SubFive.sort_values('Data_Value')
        df1SubFive = df1SubFive.reset_index(drop=True)
        df1SubFiveLen = len(df1SubFive.index)
        
        df1SubSix = df1.loc[(df1[column] == 1) & (df1['2016'] == 1)]
        df1SubSix = df1SubSix.sort_values('Data_Value')
        df1SubSix = df1SubSix.reset_index(drop=True)
        df1SubSixLen = len(df1SubSix.index)
        
        df1SubSeven = df1.loc[(df1[column] == 1) & (df1['2017'] == 1)]
        df1SubSeven = df1SubSeven.sort_values('Data_Value')
        df1SubSeven = df1SubSeven.reset_index(drop=True)
        df1SubSevenLen = len(df1SubSeven.index)
        
        
        twentyfivePercentVal = df1SubFive.at[(df1SubFiveLen//4),'Data_Value']
        thirtythreePercentVal = df1SubSix.at[(df1SubSixLen//3),'Data_Value']
        fiftyPercentVal = df1SubSeven.at[(df1SubSevenLen//2),'Data_Value']
        
        
        df1 = df1.drop(df1[(df1[column] == 1) & (df1['2015'] == 1) & (df1['Data_Value'] < twentyfivePercentVal)].index)
        df1 = df1.drop(df1[(df1[column] == 1) & (df1['2016'] == 1) & (df1['Data_Value'] < thirtythreePercentVal)].index)
        df1 = df1.drop(df1[(df1[column] == 1) & (df1['2017'] == 1) & (df1['Data_Value'] < fiftyPercentVal)].index)

        df1 = df1.reset_index(drop=True)
        
    return df1

#allBias = [1,1,1,-1,1,1,-1,0,1,-1,1,-1,0]
#fetchData(allBias)