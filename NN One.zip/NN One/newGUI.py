# -*- coding: utf-8 -*-
from tkinter import *
import csv, random
import newAlgorithm
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from cycler import cycler

# Takes data from csv and puts it into a list of dictionaries

def randomiseDataToList(input_string):
    with open(input_string) as input_file:
        input_reader = csv.DictReader(input_file, delimiter=',')
        dict_list = []
        for line in input_reader:
            dict_list.append(line)
        random.shuffle(dict_list)
        return dict_list


def filterData(dict_list, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12):
    print(dict_list)
    
    i = 0
    remove_set = set()
    for line in dict_list:
        if line["Male"] == '1':
            if random.random() * 100 > var1:
                remove_set.add(i)                    #100 - the percentage set in the gui is added to the set
        i+=1
    i = 0
    for line in dict_list:
        if line["Female"] == '1':
            if random.random() * 100 > var2:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["White, non-hispanic"] == '1':
            if random.random() * 100 > var3:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["Black, non-hispanic"] == '1':
            if random.random() * 100 > var4:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["Asian"] == '1':
            if random.random() * 100 > var5:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["North American Native"] == '1':
            if random.random() * 100 > var6:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["Hispanic, any race"] == '1':
            if random.random() * 100 > var7:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["0-17"] == '1':
            if random.random() * 100 > var8:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["18-39"] == '1':
            if random.random() * 100 > var9:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["40-64"] == '1':
            if random.random() * 100 > var10:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["65-84"] == '1':
            if random.random() * 100 > var11:
                remove_set.add(i)
        i+=1
    i = 0
    for line in dict_list:
        if line["85 and older"] == '1':
            if random.random() * 100 > var12:
                remove_set.add(i)
        i+=1
    
    remove_descending_order = sorted(remove_set, reverse=True)       #sorts the set into descending order
    for line_number in remove_descending_order:
        del dict_list[line_number]                                   #removes every index in the set from the list
    return dict_list


def dictsToCsv(dict_list, output_string):
    with open(output_string, mode='w', newline='') as output_file:
        output_writer = csv.DictWriter(output_file, dict_list[0].keys(), delimiter=',', quotechar='"')
        output_writer.writeheader()
        for line in dict_list:
            output_writer.writerow(line)


class Window(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master = master
        
        Label(root, text="Bias Machine", font=("Helvetica", 18)).grid(row=0, column=0, columnspan=2, ipadx=5, ipady=5)
        
        #Sliders
        
        Label(root, text="Male (%)").grid(row=1, column=0, ipadx=5, ipady=5)
        self.scale1Var = IntVar()
        self.scale1Var.set(100)
        self.scale1 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale1Var)
        self.scale1.grid(row=2, column=0, ipadx=5, ipady=5)
        
        Label(root, text="Female (%)").grid(row=1, column=1, ipadx=5, ipady=5)
        self.scale2Var = IntVar()
        self.scale2Var.set(100)
        self.scale2 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale2Var)
        self.scale2.grid(row=2, column=1, ipadx=5, ipady=5)
              
        Label(root, text="White (%)").grid(row=3, column=0, ipadx=5, ipady=5)
        self.scale3Var = IntVar()
        self.scale3Var.set(100)
        self.scale3 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale3Var)
        self.scale3.grid(row=4, column=0, ipadx=5, ipady=5)
              
        Label(root, text="Black (%)").grid(row=3, column=1, ipadx=5, ipady=5)
        self.scale4Var = IntVar()
        self.scale4Var.set(100)
        self.scale4 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale4Var)
        self.scale4.grid(row=4, column=1, ipadx=5, ipady=5)
              
        Label(root, text="Asian (%)").grid(row=5, column=0, ipadx=5, ipady=5)
        self.scale5Var = IntVar()
        self.scale5Var.set(100)
        self.scale5 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale5Var)
        self.scale5.grid(row=6, column=0, ipadx=5, ipady=5)
              
        Label(root, text="North American Native (%)").grid(row=5, column=1, ipadx=5, ipady=5)
        self.scale6Var = IntVar()
        self.scale6Var.set(100)
        self.scale6 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale6Var)
        self.scale6.grid(row=6, column=1, ipadx=5, ipady=5)
                        
        Label(root, text="Hispanic (%)").grid(row=7, column=0, ipadx=5, ipady=5)
        self.scale7Var = IntVar()
        self.scale7Var.set(100)
        self.scale7 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale7Var)
        self.scale7.grid(row=8, column=0, ipadx=5, ipady=5)
        
        Label(root, text="0-17 (%)").grid(row=7, column=1, ipadx=5, ipady=5)
        self.scale8Var = IntVar()
        self.scale8Var.set(100)
        self.scale8 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale8Var)
        self.scale8.grid(row=8, column=1, ipadx=5, ipady=5)
        
        Label(root, text="18-39 (%)").grid(row=9, column=0, ipadx=5, ipady=5)
        self.scale9Var = IntVar()
        self.scale9Var.set(100)
        self.scale9 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale9Var)
        self.scale9.grid(row=10, column=0, ipadx=5, ipady=5)
        
        Label(root, text="40-64 (%)").grid(row=9, column=1, ipadx=5, ipady=5)
        self.scale10Var = IntVar()
        self.scale10Var.set(100)
        self.scale10 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale10Var)
        self.scale10.grid(row=10, column=1, ipadx=5, ipady=5)
        
        Label(root, text="65-84 (%)").grid(row=11, column=0, ipadx=5, ipady=5)
        self.scale11Var = IntVar()
        self.scale11Var.set(100)
        self.scale11 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale11Var)
        self.scale11.grid(row=12, column=0, ipadx=5, ipady=5)
        
        Label(root, text="85+ (%)").grid(row=11, column=1, ipadx=5, ipady=5)
        self.scale12Var = IntVar()
        self.scale12Var.set(100)
        self.scale12 = Scale(root, from_=0, to=100, orient=HORIZONTAL, resolution=1, variable=self.scale12Var)
        self.scale12.grid(row=12, column=1, ipadx=5, ipady=5)
        
        Button(root, text="Train", command=self.train).grid(row=13, columnspan=2, padx=5, pady=5, ipadx=5, ipady=5)

    def train(self):
        newWindow = Toplevel(root)
        Label(newWindow, text="Male = "+str(self.scale1Var.get())+"%").pack()
        Label(newWindow, text="Female = "+str(self.scale2Var.get())+"%").pack()
        Label(newWindow, text="White = "+str(self.scale3Var.get())+"%").pack()
        Label(newWindow, text="Black = "+str(self.scale4Var.get())+"%").pack()
        Label(newWindow, text="Asian = "+str(self.scale5Var.get())+"%").pack()
        Label(newWindow, text="North American Native = "+str(self.scale6Var.get())+"%").pack()
        Label(newWindow, text="Hispanic = "+str(self.scale7Var.get())+"%").pack()
        Label(newWindow, text="0-17 = "+str(self.scale8Var.get())+"%").pack()
        Label(newWindow, text="18-39 = "+str(self.scale9Var.get())+"%").pack()
        Label(newWindow, text="40-64 = "+str(self.scale10Var.get())+"%").pack()
        Label(newWindow, text="65-84 = "+str(self.scale11Var.get())+"%").pack()
        Label(newWindow, text="85+ = "+str(self.scale12Var.get())+"%").pack()
        dict_list = randomiseDataToList("Binary_Eye_Health_Test.csv")
        dict_list2 = filterData(dict_list, self.scale1Var.get(), self.scale2Var.get(), self.scale3Var.get(), self.scale4Var.get(), self.scale5Var.get(), self.scale6Var.get(), self.scale7Var.get(), self.scale8Var.get(), self.scale9Var.get(), self.scale10Var.get(), self.scale11Var.get(), self.scale12Var.get())
        dictsToCsv(dict_list2, "Returned_Data.csv")
        
        # train model
        dataframe = newAlgorithm.createModel() # create model based on these values
        
        self.graph(dataframe)
        
    #Creation of graph screen
    def graph(self, dataframe): #dataframe
        
        
        
        # set up new window

        graphWindow = Toplevel(root)
        graphWindow.title("Graph")
        graphWindow.geometry("1400x700")
        #titleLbl = tk.Label(graphWindow, text="Percentage of people who are severly visually impaired or blind", font=("Helvetica", 16))
        #titleLbl.grid(row=0, column=0, ipadx=50, ipady=15)
        dfFinalData = ''

        
        dataframesList = []
        indexList = []
        ageList = ['0-17', '18-39', '40-64', '65-84', '85 and older', 'All Ages']
        genderList = ['Male', 'Female', 'All Genders']
        raceList = ['Asian', 'Black, non-hispanic', 'Hispanic, any race', 'North American Native',
                    'White, non-hispanic', 'Other', 'All Races']

        for i in ageList:
            for j in genderList:
                for k in raceList:
                    tempDF = dataframe.loc[(dataframe[i] == 1) & (dataframe[j] == 1) & (dataframe[k] == 1)]
                    dataframesList.append(tempDF.iloc[:, [0,1,2,3,20]])
                    tempDF = '' # wipe variable
                    indexList.append(i + " " + k + " " + j)
  
        yearList = []
        valueList = []
        finalDataList = []
        
        
        for i in dataframesList:
            #print(dataframesList[i])
            for index, row in i.iterrows():
                if (row['2014'] == 1):
                    yearList.append("2014")
                    valueList.append(round(row['Data_Values'][0], 3))
                elif (row['2015'] == 1):
                    yearList.append("2015")
                    valueList.append(round(row['Data_Values'][0], 3))
                elif (row['2016'] == 1):
                    yearList.append("2016")
                    valueList.append(round(row['Data_Values'][0], 3))
                elif (row['2017'] == 1):
                    yearList.append("2017")
                    valueList.append(round(row['Data_Values'][0], 3))
                    
            #finalDataList.append({"Year": yearList, 'Percentage': valueList})
            finalData = {"Year": yearList, 'Percentage': valueList}
            finalDataList.append(pd.DataFrame(finalData, columns=['Year','Percentage']))

        
        # create numpy array of all lines
        tempListA, tempListB, tempListC, tempListD = [], [], [], []
        for i in finalDataList:
            tempList = []
            y = i.iloc[:, 1:]
            count = 0
            for ind in y.index:
                if count == 0:
                    tempListA.append(y['Percentage'][ind])
                elif count == 1:
                    tempListB.append(y['Percentage'][ind])
                elif count == 2:
                    tempListC.append(y['Percentage'][ind])
                else:
                    tempListD.append(y['Percentage'][ind])
                    count = -1
                count += 1
        
        npList = [tempListA, tempListB, tempListC, tempListD]
        npArray = np.array(npList)
       # print(npArray)
        
        
        # create graph plot using matplotlib
        figure2 = plt.Figure(figsize=(10,6), dpi=100)
        ax2 = figure2.add_subplot(111)
        
        #cy = cycler('color', ['black','red','green'])
        
        n = len(finalDataList)
        new_colors = [plt.get_cmap('jet')(1. * i/n) for i in range(n)]
        propCycle = (cycler('color', new_colors))
        ax2.set_prop_cycle(propCycle)
        
        
        #ax2.set_prop_cycle(cy)
        
        ax2.plot(npArray)
        ax2.set_title('Percentage of people who are severely visually impaired or blind')
        ax2.legend(indexList, bbox_to_anchor=(1.01, 1), loc='upper left', fontsize='xx-small', ncol = 3)
        
        labels = [item.get_text() for item in ax2.get_xticklabels()]
        labels[1], labels[3], labels[5], labels[7] = '2014', '2015', '2016', '2017'
        ax2.set_xticklabels(labels)
        
        
        figure2.tight_layout()
        figure2.subplots_adjust(right=0.7)
        
        
        line2 = FigureCanvasTkAgg(figure2, graphWindow)
        line2.draw()
        line2.get_tk_widget().grid(row=1, column=0)
        
        
root = Tk()
app = Window(root)
root.wm_title("Bias Machine")
root.geometry("300x600")
root.mainloop()