import torch
import pandas as pd
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from numpy.random import seed

def prepareData():
    seed(1)
    #Get training dataset from file (as pandas dataframe)
    df1 = pd.read_csv('Returned_Data.csv')
    
    #Get testing dataset from file (as pandas dataframe)
    #df2 = pd.read_csv('EyeHealthFinalDataCSV.csv')
    
    #df1 = data.fetchData(allBias)
    
    
    #Shuffle data
    df1 = df1.sample(frac=1)


    #Split array into attributes and result
    my_x = df1.iloc[:, :20] # Holds the attributes (sample size ignored)
    temp_y = df1.iloc[:, 20:]
    my_y = temp_y.iloc[:, :1] # Holds the data value


    #Turn the arrays into torch tensors
    y_values = torch.tensor(my_y['Data_Value'].values, dtype=torch.float32)
    x_values = torch.tensor(my_x.values, dtype=torch.float32)
    

    #Separate arrays into training and testing data (ratio roughly 2:1)
    ratioAmount = len(df1.index) - (len(df1.index) // 3)
    
    x_train = torch.tensor(x_values[:ratioAmount, :], dtype=torch.float32)
    x_test = torch.tensor(x_values[ratioAmount:, :], dtype=torch.float32)
    y_train = torch.tensor(y_values[:ratioAmount], dtype=torch.float32)
    y_test = torch.tensor(y_values[ratioAmount:], dtype=torch.float32)
    
    y_train = y_train.unsqueeze(1)
    
    alldata = [x_train, x_test, y_train, y_test]
    
    return alldata

# Set up neural net values
N = 13772 # This is the batch size (number of samples processed before network is updated)
D_in = 20 # This is the input dimension (number of attributes the nn takes in)
H = 40 # This is the hidden dimension (number of layers in the nn)
D_out = 1 # This is the output dimension (number of values the nn produces)

#NN custom module
class TwoLayerNet(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        super(TwoLayerNet, self).__init__()
        self.linear1 = torch.nn.Linear(D_in, H)
        self.linear2 = torch.nn.Linear(H, D_out)

    def forward(self, x):
        h_relu = self.linear1(x).clamp(min=0)
        y_pred = self.linear2(h_relu)
        return y_pred
    
    
    
def createModel():
    #Create new model
    #manual_seed(seed)
    model = TwoLayerNet(D_in, H, D_out)

    #Define loss function and optimizer
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=1e-4) # this updates the weights for us

    #Get data
    myData = prepareData()
    x_train = myData[0]
    y_train = myData[2]

    #Train NN
    for t in range(200): # num of epochs = 10000
        y_pred = model(x_train)

        loss = criterion(y_pred, y_train)
        
        if (t % 200 == 0):
            print(t, loss.item())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    #Get testing dataset from file (as pandas dataframe)
    df2 = pd.read_csv('EyeHealthFinalDataCSV.csv')
    
    #Turn test data into tensor
    #newData = df2.iloc[:, :20] #test_tensor = torch.Tensor(test.values)
    
    #my_x = df1.iloc[:, :20]
    newData = torch.tensor(df2.values, dtype=torch.float32)
    #newDAta = torch.tensor(newData, dtype=torch.float32)
    
    #Use NN
    y_pred = model.eval()
    output = model(newData)
    output_vals = output.tolist()
    
    #Add output values to dataframe to send back
    df2['Data_Values'] = output_vals
    
    return df2